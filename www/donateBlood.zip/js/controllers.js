angular.module('app.controllers', [])
  
.controller('pageCtrl', function($scope) {

})
 